# JSRobot
A platform game you play by coding in JavaScript!
<br><br>
<img src="images/robotbig.png" width="200px">


## Getting Started
Click the `Clone or download` button above to download a zip file or clone the
repository, then open `index.html`. Have fun :D
